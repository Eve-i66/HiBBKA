function [f1, gmean] = jwrapper_KNN(sFeat, label, opts)
    if isfield(opts, 'k'), k = opts.k; end
    if isfield(opts, 'cv'), cv = opts.cv; end

    f1_scores = zeros(cv.NumTestSets, 1);
    gmeans = zeros(cv.NumTestSets, 1);

    for i = 1:cv.NumTestSets
        % Define training & validation sets
        trainIdx = cv.training(i);
        testIdx = cv.test(i);
        xtrain = sFeat(trainIdx, :); 
        ytrain = label(trainIdx);
        xvalid = sFeat(testIdx, :);  
        yvalid = label(testIdx);

        % Training model
        % boxConstraint = 1; % Box constraint
        % My_Model = fitcsvm(xtrain, ytrain, 'KernelFunction', 'rbf', 'KernelScale', 'auto', 'BoxConstraint', boxConstraint);
        % My_Model = fitcknn(xtrain,ytrain,'NumNeighbors',k);
        My_Model = fitctree(xtrain, ytrain); 
        % Prediction
        pred = predict(My_Model, xvalid);
        % pred = str2double(pred);
        % Confusion matrix
        C = confusionmat(yvalid, pred);
        tp = C(2, 2); % True positives
        fp = C(1, 2); % False positives
        fn = C(2, 1); % False negatives
        tn = C(1, 1);    
        precision = tp / (tp + fp);
        recall = tp / (tp + fn);
        specificity = tn / (tn + fp);   
        % F1 score
        f1_scores(i) = 2 * (precision * recall) / (precision + recall);
        gmeans(i) = sqrt(recall * specificity);
    end

    f1 = mean(f1_scores);
    gmean = mean(gmeans);
    if isnan(f1)
        f1 = 0;
    end
    if isnan(gmean)
        gmean = 0;
    end
end