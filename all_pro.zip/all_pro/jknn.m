function f1_score = jknn(feat,label,opts)
% Default of k-value
if isfield(opts,'k'), k = opts.k; end
if isfield(opts,'Model'), Model = opts.Model; end

% Define training & validation sets
trainIdx = Model.training;    testIdx = Model.test;
xtrain   = feat(trainIdx,:); ytrain  = label(trainIdx);
xvalid   = feat(testIdx,:);  yvalid  = label(testIdx);
% Training model
My_Model = fitcknn(xtrain,ytrain,'NumNeighbors',k); 
% Prediction
pred     = predict(My_Model,xvalid);
% confusion matrix
C = confusionmat(yvalid, pred);
tp = C(2, 2); % True positives
fp = C(1, 2); % False positives
fn = C(2, 1); % False negatives
    
precision = tp / (tp + fp);
recall = tp / (tp + fn);
    
% 计算 F1 分数
f1_score= 2 * (precision * recall) / (precision + recall);
fprintf('\n f1_score: %g %%',100 * f1_score);
end


