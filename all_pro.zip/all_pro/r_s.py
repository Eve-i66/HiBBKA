import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold, ParameterGrid
from sklearn.metrics import precision_score, recall_score
from sklearn.neighbors import KDTree
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
from collections import Counter
from imblearn.over_sampling import SMOTE
from rbu import RBU, mutual_class_potential

# Load data
filename = 'CHD2_1.csv'
data = pd.read_csv(filename)
print(data)
data = data.values
print("values", type(data))
print("shape", type(data.shape))
labels = data[:, -1]
print(labels)
features = data[:, :-1]

# Define performance metric record lists
g_mean_scores = []
mcc_scores = []

kf = StratifiedKFold(n_splits=5, shuffle=True)

# grid search parameters
param_grid = {
    'k_values': [5,7,9,11,13,15,17,19,21,23,25,50],  # KDTree 的 k 值
    'rbu_ratios': [0.1, 0.15, 0.2, 0.25, 0.3,0.35,0.4,0.45,0.5,0.55,0.6]  # RBU 的欠采样率
}

# Create parameter grid
grid = ParameterGrid(param_grid)

# Initialization
best_g_mean = -float('inf')
best_mcc = -float('inf')
best_params = None

num_repetitions = 5  # 重复实验次数

# Iterate through all parameter combinations in the grid
for params in grid:
    k = params['k_values']
    rbu_ratio = params['rbu_ratios']

    g_mean_scores = []
    mcc_scores = []

    for _ in range(num_repetitions):
        # Initialize the result lists for each repeated experiment
        fold_g_mean_scores = []
        fold_mcc_scores = []

        for train_index, test_index in kf.split(features, labels):
            X_train, X_test = features[train_index], features[test_index]
            y_train, y_test = labels[train_index], labels[test_index]

            # KDTree
            tree = KDTree(X_train, leaf_size=30)
            distances, indices = tree.query(X_train, k=k)
            neighbors_indices = indices[:, 1:]
            neighbors_distances = distances[:, 1:]
            y_train = pd.DataFrame(y_train)
            y_train = y_train.astype(int)

            same_label_counts = []
            for i in range(len(X_train)):
                current_label = y_train.iloc[i, 0]
                neighbors_labels = y_train.iloc[neighbors_indices[i], 0]
                same_label_count = sum(neighbors_labels == current_label)
                same_label_counts.append(same_label_count)

            indices_to_remove = np.where(np.array(same_label_counts) == 0)[0]
            traindata_X = np.delete(X_train, indices_to_remove, axis=0)
            traindata_y = y_train.drop(indices_to_remove)

            class_counts = Counter(traindata_y[0])
            minority_class = class_counts.most_common()[-1][0]
            majority_class = class_counts.most_common()[0][0]

            # class_indices
            minority_class_indices = np.where(traindata_y[0] == minority_class)[0]
            majority_class_indices = np.where(traindata_y[0] == majority_class)[0]

            # class_indices samples
            minority_samples = traindata_X[minority_class_indices]
            majority_samples = traindata_X[majority_class_indices]

            # target
            minority_y = traindata_y.iloc[minority_class_indices, 0]
            majority_y = traindata_y.iloc[majority_class_indices, 0]

            # Calculate
            majority_potentials = np.zeros(len(majority_samples))
            for i, point in enumerate(majority_samples):
                majority_potentials[i] = mutual_class_potential(
                    point, majority_samples, minority_samples, gamma=1.0, p_norm=2
                )

            mean = np.mean(majority_potentials)
            std_dev = np.std(majority_potentials)
            lower_threshold = mean - 3 * std_dev
            upper_threshold = mean + 3 * std_dev

            anomaly_indices = []
            for i in range(majority_potentials.shape[0]):
                if np.any(majority_potentials[i] < lower_threshold) or np.any(majority_potentials[i] > upper_threshold):
                    anomaly_indices.append(i)

            majority_points = np.delete(majority_samples, anomaly_indices, axis=0)
            X_train = np.concatenate((majority_points, minority_samples))

            majority_y = np.delete(majority_y, anomaly_indices, axis=0)
            y_train = np.concatenate((majority_y, minority_y))


            rbu = RBU(ratio=rbu_ratio)
            X_resampled, y_resampled = rbu.fit_sample(X_train, y_train)
            X_resampled = pd.DataFrame(X_resampled)
            y_resampled = pd.DataFrame(y_resampled)


            sm = SMOTE(k_neighbors=5, sampling_strategy=1)
            X_resampled1, y_resampled1 = sm.fit_resample(X_resampled, y_resampled)

            # model train
            stacking_model = SVC(kernel='rbf', C=1)
            stacking_model.fit(X_resampled1, y_resampled1)

            # prediction
            y_pred = stacking_model.predict(X_test)

            # calculate
            def gmean(y_true, y_pred):
                precision = precision_score(y_true, y_pred)
                recall = recall_score(y_true, y_pred)
                return (precision * recall) ** 0.5

            def mcc(y_true, y_pred):
                tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
                return (tp * tn - fp * fn) / ((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)) ** 0.5

            g_mean = gmean(y_test, y_pred)
            mcc_score = mcc(y_test, y_pred)

            fold_g_mean_scores.append(g_mean)
            fold_mcc_scores.append(mcc_score)

        # Record
        g_mean_scores.append(sum(fold_g_mean_scores) / len(fold_g_mean_scores))
        mcc_scores.append(sum(fold_mcc_scores) / len(fold_mcc_scores))

    # mean metrics
    avg_g_mean = sum(g_mean_scores) / len(g_mean_scores)
    avg_mcc = sum(mcc_scores) / len(mcc_scores)

    # Update the best parameters
    if avg_g_mean > best_g_mean or (avg_g_mean == best_g_mean and avg_mcc > best_mcc):
        best_g_mean = avg_g_mean
        best_mcc = avg_mcc
        best_params = params

# 输出最佳结果
print("Best Parameters:", best_params)
print("Best G-Mean:", best_g_mean)
print("Best MCC:", best_mcc)
