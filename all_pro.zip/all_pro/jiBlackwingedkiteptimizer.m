%%  Black-winged Kite Algorithm
function iBKA=jiBlackwingedkiteptimizer(feat,label,opts)
%% ----------------Initialize the locations of Blue Sheep------------------%
dim = size(feat,2); 
lb    = 0*ones(1,dim);
ub    = 1*ones(1,dim); 
thres = 0.5; 
bounds = [lb(:),ub(:)];

if isfield(opts,'N'), N = opts.N; end
if isfield(opts,'T'), T = opts.T; end
if isfield(opts,'thres'), thres = opts.thres; end

% Objective function
fobj = @jFitnessFunction; 
% Number of dimensions
XPos=good_point(N,dim,bounds,fobj,feat,label,thres,opts);
p=0.9;r=rand;
XFit=zeros(1,N);
for i=1:N
    XFit(i)=fobj(feat,label,(XPos(i,:)> thres),opts); 
end
curve=zeros(1,T);
P   = zeros(N,dim); 
for i =1:N
    for j =1:dim
       P(i,j) = lb(j) + (ub(j) - lb(j)) * rand();
    end
end

%% -------------------Start iteration------------------------------------%

for t=1:T
    [~,sorted_indexes]=sort(XFit);
    XLeader_Pos=XPos(sorted_indexes(1),:);
    XLeader_Fit = XFit(sorted_indexes(1));
%% -------------------Attacking behavior-------------------%

    for i=1:N
        
        n=0.05*exp(-2*(t/T)^2);
        if p<r
           XPosNew(i,:)=XPos(i,:)+n.*(1+sin(r))*XPos(i,:);
          
        else
           
            XPosNew(i,:)= XPos(i,:).*(n*(2*rand(1,dim)-1)+1);
        end
        XPosNew(i,:) = max(XPosNew(i,:),lb);
        XPosNew(i,:) = min(XPosNew(i,:),ub);
%% ------------ Select the optimal fitness value--------------%
        
        XFit_New(i)=fobj(feat,label,(XPosNew(i,:)> thres),opts);     

        if(XFit_New(i)<XFit(i))
            XPos(i,:) = XPosNew(i,:);
            XFit(i) = XFit_New(i);        
        end
        xnew(i, :)= calculate_positions(XPos, lb, ub, t, T, XLeader_Fit);
        Xfit(i)=fobj(feat,label,(Xpos(i,:)> thres),opts);


        if(Xfit(i)<XFit(i))
            XPos(i,:) = Xpos(i,:);
            XFit(i) = Xfit(i);        
        end
%% -------------------Migration behavior-------------------%
 
        m=2*sin(r+pi/2);
        s = randi([1,30],1);
        r_XFitness=XFit(s);
        ori_value = rand(1,dim);cauchy_value = tan((ori_value-0.5)*pi);
      
        if XFit(i)< r_XFitness
            XPosNew(i,:)=XPos(i,:)+cauchy_value(:,dim).* (XPos(i,:)-XLeader_Pos);
        else
            XPosNew(i,:)=XPos(i,:)+cauchy_value(:,dim).* (XLeader_Pos-m.*XPos(i,:));
        end
        XPosNew(i,:) = max(XPosNew(i,:),lb);
        XPosNew(i,:) = min(XPosNew(i,:),ub);
%% --------------  Select the optimal fitness value---------%

        XFit_New(i)=fobj(feat,label,(XPosNew(i,:)> thres),opts);
        if(XFit_New(i)<XFit(i))
            XPos(i,:) = XPosNew(i,:);
            XFit(i) = XFit_New(i);
        end
        % Replace the following segment with a call to the new function
        xnew(i, :)= calculate_positions(XPos, lb, ub, t, T, XLeader_Fit);
        Xfit(i)=fobj(feat,label,(Xpos(i,:)> thres),opts); 
        xfitnew(i)=fobj(feat,label,(xnew(i,:)> thres),opts);
        

        if(xfitnew(i)<XFit(i))
             XPos(i,:) = xnew(i,:);
             XFit(i) = xfitnew(i);        
        end
    end

        
    %% -------Update the optimal Black-winged Kite----------%

        if(XFit<XLeader_Fit)
          Best_Fitness_BKA=XFit(i);
          Best_Pos_BKA=XPos(i,:);
        else
          Best_Fitness_BKA=XLeader_Fit;
          Best_Pos_BKA=XLeader_Pos;
        end
   

        curve(t)=Best_Fitness_BKA;
        fprintf('\nIteration %d Best (iBKA)= %f',t,curve(t))
        
end
Pos   = 1:dim; 
Sf    = Pos((Best_Pos_BKA > thres) == 1);
sFeat = feat(:,Sf); 
% Store results
iBKA.sf = Sf; 
iBKA.ff = sFeat; 
iBKA.nf = length(Sf); 
iBKA.c  = curve;
iBKA.f  = feat;
iBKA.l  = label;
end