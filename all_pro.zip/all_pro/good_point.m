
function x_total = good_point(pop_size,dimension,bounds,fobj,feat,label,thres,opts)
p = zeros(pop_size,dimension);
prime_number_min = dimension*2 +3;

while 1
    if isprime(prime_number_min)==1
        break;
    else
       prime_number_min = prime_number_min + 1;
    end
end

for i = 1:pop_size
    for j = 1:dimension
        r = mod(2*cos(2*pi*j/prime_number_min)*i,1);
        p(i,j) = bounds(j,1)+r*(bounds(j,2)-bounds(j,1));
        q(i,j) = (bounds(j,1)+bounds(j,2))-p(i,j);
    end
end
pop = p;
index = zeros(size(pop,1));
for i=1:size(pop,1)
    if(fobj(feat,label,(pop(i, :)> thres),opts)<fobj(feat,label,(q(i, :)> thres),opts))
        index(i)=1;
    else
        pop(i,:)=q(i,:);
    end
end
x_reverse=pop(index==1,:);
tlb=min(x_reverse);
tub=max(x_reverse);
for i = 1:size(x_reverse, 1)
    x_reverse(i,:)=rand().*(tlb+tub)-x_reverse(i,:);
end
pop(index==1,:)=x_reverse;
x_total=pop;
end


