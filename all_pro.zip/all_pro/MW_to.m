function xnew = MW_to(XPos, lb, ub, t, T, XLeader_Fit)
    ss = randi([800, 1200]);
    aa = ss * (1 / ss) .^ (1 - (t / T));
    n = -2.5 + 5 * rand();
    sgamma = (1 / sqrt(aa)) * exp(-(n^2 / 2)) * cos(5 * n);
    p1 = sgamma * (ub - XPos);
    p2 = sgamma * (XPos - lb);

    if rand() < 0.5
        Xpos = XPos + p1;
    else
        Xpos = XPos + p2;
    end

    f = rand();
    xnew = f * Xpos + (1 - f) * XLeader_Fit;
end