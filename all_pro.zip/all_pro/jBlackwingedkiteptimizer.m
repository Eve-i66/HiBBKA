%%  Black-winged Kite Algorithm
function bka=jBlackwingedkiteptimizer(feat,label,opts)
%% ----------------Initialize the locations of Blue Sheep------------------%
% Parameters
lb    = 0;
ub    = 1; 
thres = 0.5; 

if isfield(opts,'N'), N = opts.N; end
if isfield(opts,'T'), max_Iter = opts.T; end
if isfield(opts,'thres'), thres = opts.thres; end

% Objective function
fun = @jFitnessFunction; 
% Number of dimensions
dim = size(feat,2); 

p=0.9;
r=rand;
X   = zeros(N,dim); 
for i =1:N
    for j =1:dim
        X(i,j) = lb + (ub - lb) * rand();
    end
end
Fit=zeros(1,N);
for i=1:N
    Fit(i)=fun(feat,label,(X(i,:) > thres),opts);
end

curve=zeros(1,max_Iter);
%% -------------------Start iteration------------------------------------%
t = 1;
while t<= max_Iter
    [~,sorted_indexes]=sort(Fit);
    XLeader_Pos=X(sorted_indexes(1),:);
    XLeader_Fit = Fit(sorted_indexes(1));
%% -------------------Attacking behavior-------------------%
    for i=1:N
        n=0.05*exp(-2*(t/max_Iter)^2);
        if p<r
            XNew(i,:)=X(i,:)+n.*(1+sin(r))*X(i,:);
        else
            XNew(i,:)= X(i,:).*(n*(2*rand(1,dim)-1)+1);
        end
        XNew(i,:) = max(XNew(i,:),lb);
        XNew(i,:) = min(XNew(i,:),ub);%%Boundary checking
%% ------------ Select the optimal fitness value--------------%
        XFit_New(i)=fun(feat,label,(XNew(i,:) > thres),opts);
        if(XFit_New(i)<Fit(i))
            X(i,:) = XNew(i,:);
            Fit(i) = XFit_New(i);
        end
%% -------------------Migration behavior-------------------%
        m=2*sin(r+pi/2);
        s = randi([1,30],1);
        r_XFitness=Fit(s);
        ori_value = rand(1,dim);cauchy_value = tan((ori_value-0.5)*pi);
        if Fit(i)< r_XFitness
            XNew(i,:)=X(i,:)+cauchy_value(:,dim).* (X(i,:)-XLeader_Pos);
        else
            XNew(i,:)=X(i,:)+cauchy_value(:,dim).* (XLeader_Pos-m.*X(i,:));
        end
        XNew(i,:) = max(XNew(i,:),lb);
        XNew(i,:) = min(XNew(i,:),ub); %%Boundary checking
%% --------------  Select the optimal fitness value---------%
        XFit_New(i)=fun(feat,label,(XNew(i,:)> thres),opts);
        if(XFit_New(i)<Fit(i))
            X(i,:) = XNew(i,:);
            Fit(i) = XFit_New(i);
        end
    end


    %% -------Update the optimal Black-winged Kite----------%
    if(Fit<XLeader_Fit)
        Best_Fitness_BKA=Fit(i);
        Best_Pos_BKA=X(i,:);
    else
        Best_Fitness_BKA=XLeader_Fit;
        Best_Pos_BKA=XLeader_Pos;
    end
    curve(t) = Best_Fitness_BKA;
    fprintf('\nIteration %d Best (bak)= %f',t,curve(t))
    t=t+1;
end
Pos   = 1:dim; 
Sf    = Pos((Best_Pos_BKA > thres) == 1);
sFeat = feat(:,Sf); 
% Store results
bka.sf = Sf; 
bka.ff = sFeat; 
bka.nf = length(Sf); 
bka.c  = curve;
bka.f  = feat;
bka.l  = label;
end